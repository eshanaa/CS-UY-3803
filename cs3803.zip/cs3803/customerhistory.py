from flask import Flask, render_template, request, session, url_for, redirect, abort
import pymysql.cursors
import datetime

def view():
    return render_template('searchcustomer.html')

def get(conn):
    airline = session["employer"]
    email = request.form['email']
    cursor = conn.cursor()

    get_customer_history = "SELECT T.flight_number as flight_number, T.depart_ts as depart_time, P.sell_price as purchase_price FROM purchases as P, ticket as T WHERE P.ticket_id = T.ticket_id and T.airline_name = %s AND P.email = %s ORDER BY depart_time DESC"
    cursor.execute(get_customer_history, (airline, email))
    customer_history = cursor.fetchall()

    if not customer_history:
        return render_template('searchcustomer.html', customer=email, error="No flights found or invalid email")
    return render_template('searchcustomer.html', customer=email, flight_history=customer_history)
