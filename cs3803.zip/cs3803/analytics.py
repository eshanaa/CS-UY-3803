from flask import Flask, render_template, request, session, url_for, redirect, abort
import pymysql.cursors
import datetime

def financial(conn):
    airline = session["employer"]
    cursor = conn.cursor()

    # frequent customers
    top_customers = "SELECT P.email, COUNT(P.email) as frequency FROM purchases as P, ticket as T WHERE P.ticket_id = T.ticket_id and T.airline_name = %s AND P.purchase_ts BETWEEN DATE_SUB(NOW(), INTERVAL 1 YEAR) AND NOW() GROUP BY P.email ORDER BY frequency DESC"
    cursor.execute(top_customers, (airline))
    top_customers = cursor.fetchall()

    # reports of purchases
    reports = "SELECT YEAR(P.purchase_ts) as Year, MONTH(P.purchase_ts) as Month, COUNT(T.flight_number) as total_purchases FROM purchases as P, ticket as T WHERE P.ticket_id = T.ticket_id and T.airline_name = %s GROUP BY Year, Month ORDER BY Year, Month"
    cursor.execute(reports, (airline))
    summary = cursor.fetchall()
    print(summary)
    
    # revenue for the past month
    month_revenue = "SELECT SUM(P.sell_price) as Revenue FROM purchases as P, ticket as T WHERE P.ticket_id = T.ticket_id and T.airline_name = %s AND P.purchase_ts BETWEEN DATE_SUB(NOW(), INTERVAL 60 DAY)"
    cursor.execute(month_revenue, (airline))
    month_revenue = cursor.fetchone()

    # revenue for the past year
    yearly_revenue = "SELECT SUM(P.sell_price) as Revenue FROM purchases as P, ticket as T WHERE P.ticket_id = T.ticket_id and T.airline_name = %s AND YEAR(P.purchase_ts) = YEAR(NOW())"
    cursor.execute(yearly_revenue, (airline))
    year_revenue = cursor.fetchone()

    # top 3 destinations past 3 months
    top_destinations_monthly = "SELECT B.city as destination_city, COUNT(B.city) as frequency FROM flights as F, airport as A, airport as B, ticket AS T, purchases as P WHERE B.code = F.arrival_airport_code AND A.code = F.depart_airport_code AND F.airline_name = %s and T.ticket_id = P.ticket_id and T.flight_number = F.flight_number AND F.depart_ts BETWEEN DATE_SUB(NOW(), INTERVAL 3 MONTH) AND NOW() GROUP BY B.city ORDER BY frequency DESC LIMIT 3"
    cursor.execute(top_destinations_monthly, (airline))
    top_destinations_month = cursor.fetchall()

    # top 3 destinations past year
    top_destinations_yearly = "SELECT B.city as destination_city, COUNT(B.city) as frequency FROM flights as F, airport as A, airport as B, ticket AS T, purchases as P WHERE B.code = F.arrival_airport_code AND A.code = F.depart_airport_code AND F.airline_name = %s and T.ticket_id = P.ticket_id and T.flight_number = F.flight_number AND YEAR(F.depart_ts) = YEAR(NOW()) GROUP BY B.city ORDER BY frequency DESC LIMIT 3"
    cursor.execute(top_destinations_yearly, (airline))
    top_destinations_year = cursor.fetchall()

    cursor.close()

    return render_template("staffanalytics.html", frequentflyers=top_customers,
                           popular_places_month=top_destinations_month, popular_places_year=top_destinations_year,
                           month_revenue=month_revenue[0], year_revenue=year_revenue[0],
                           summary=summary)

def get_analytics(conn):
    airline = session["employer"]
    cursor = conn.cursor()

    # frequent customers
    top_customers = "SELECT P.email, COUNT(P.email) as frequency FROM purchases as P, ticket as T WHERE P.ticket_id = T.ticket_id and T.airline_name = %s AND P.purchase_ts BETWEEN DATE_SUB(NOW(), INTERVAL 1 YEAR) AND NOW() GROUP BY P.email ORDER BY frequency DESC"
    cursor.execute(top_customers, (airline))
    top_customers = cursor.fetchall()

    # reports of purchases
    reports = "SELECT YEAR(P.purchase_ts) as Year, MONTH(P.purchase_ts) as Month, COUNT(T.flight_number) as total_purchases FROM purchases as P, ticket as T WHERE P.ticket_id = T.ticket_id and T.airline_name = %s GROUP BY Year, Month ORDER BY Year, Month"
    cursor.execute(reports, (airline))
    summary = cursor.fetchall()
    print(summary)
    # custom range
    form_ts_start = request.form['ts_start']
    form_ts_end = request.form['ts_end']

    ts_start = datetime.datetime.strptime(form_ts_start, "%Y-%m-%d")
    ts_end = datetime.datetime.strptime(form_ts_end, "%Y-%m-%d")

    # tickets sold by custom range
    custom_summary = f"SELECT YEAR(P.purchase_ts) as Year, MONTH(P.purchase_ts) as Month, COUNT(T.flight_number) as total_purchases FROM purchases as P, ticket as T WHERE P.ticket_id = T.ticket_id and T.airline_name = %s AND P.purchase_ts BETWEEN '{ts_start}' AND '{ts_end}' GROUP BY Year, Month ORDER BY Year, Month"
    cursor.execute(custom_summary, (airline))
    custom_summary = cursor.fetchall()

    # revenue for the past month
    monthly_revenue = "SELECT SUM(P.sell_price) as Revenue FROM purchases as P, ticket as T WHERE P.ticket_id = T.ticket_id and T.airline_name = %s AND YEAR(P.purchase_ts) = YEAR(NOW()) AND MONTH(P.purchase_ts) = MONTH(NOW())"
    cursor.execute(monthly_revenue, (airline))
    month_revenue = cursor.fetchone()

    # revenue for the past year
    yearly_revenue = "SELECT SUM(P.sell_price) as Revenue FROM purchases as P, ticket as T WHERE P.ticket_id = T.ticket_id and T.airline_name = %s AND YEAR(P.purchase_ts) = YEAR(NOW())"
    cursor.execute(yearly_revenue, (airline))
    year_revenue = cursor.fetchone()

    # top 3 destinations past 3 months
    top_destinations_monthly = "SELECT B.city as destination_city, COUNT(B.city) as frequency FROM flights as F, airport as A, airport as B, ticket AS T, purchases as P WHERE B.code = F.arrival_airport_code AND A.code = F.depart_airport_code AND F.airline_name = %s and T.ticket_id = P.ticket_id and T.flight_number = F.flight_number AND F.depart_ts BETWEEN DATE_SUB(NOW(), INTERVAL 3 MONTH) AND NOW() GROUP BY B.city ORDER BY frequency DESC LIMIT 3"
    cursor.execute(top_destinations_monthly, (airline))
    top_destinations_month = cursor.fetchall()

    # top 3 destinations past year
    top_destinations_yearly = "SELECT B.city as destination_city, COUNT(B.city) as frequency FROM flights as F, airport as A, airport as B, ticket AS T, purchases as P WHERE B.code = F.arrival_airport_code AND A.code = F.depart_airport_code AND F.airline_name = %s and T.ticket_id = P.ticket_id and T.flight_number = F.flight_number AND F.depart_ts BETWEEN DATE_SUB(NOW(), INTERVAL 1 YEAR) AND NOW() GROUP BY B.city ORDER BY frequency DESC LIMIT 3"
    cursor.execute(top_destinations_yearly, (airline))
    top_destinations_year = cursor.fetchall()

    cursor.close()

    return render_template("staffanalytics.html", frequentflyers=top_customers,
                           popular_places_month=top_destinations_month, popular_places_year=top_destinations_year,
                           month_revenue=month_revenue[0], year_revenue=year_revenue[0],
                           summary=summary, custom_summary=custom_summary)
