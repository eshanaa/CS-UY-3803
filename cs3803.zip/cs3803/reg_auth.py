from flask import Flask, render_template, request, session, url_for, redirect, abort
import pymysql.cursors
import datetime

def staff_auth(conn):
    # getting all the info for the staff (check ER)
    username = request.form['username'].replace("&", "&amp;").replace('"', "&quot;").replace("<", "&lt;").replace(">", "&gt;")
    password = request.form['password']
    fname = request.form['fname'].replace("&", "&amp;").replace('"', "&quot;").replace("<", "&lt;").replace(">", "&gt;")
    lname = request.form['lname'].replace("&", "&amp;").replace('"', "&quot;").replace("<", "&lt;").replace(">", "&gt;")
    DoB = request.form['DoB']
    phone = request.form['phone']
    airline_employer = request.form['employer'].replace('&nbsp;', ' ')
    email = request.form['email']

    # query
    cursor = conn.cursor()
    query = 'SELECT * FROM airline_staff WHERE username = %s'
    cursor.execute(query, (username))
    data = cursor.fetchone()
    error = None

    if (data):
        error = "This user already exists"
        session['error'] = error
        return redirect(url_for('staffreg'))

    else:
        ins = "INSERT INTO airline_staff VALUES(%s, MD5(%s), %s, %s, %s, %s)"
        cursor.execute(ins, (username, password, fname, lname, DoB, email))
        conn.commit()

        # Insert into works_for new registered employee
        employee = 'SELECT * FROM works_for WHERE username = %s AND airline_name = %s'
        cursor.execute(employee, (username, airline_employer))
        check_res = cursor.fetchone()

        # Insert phone number
        phone_ins = 'INSERT INTO staff_phone VALUES(%s, %s)'
        cursor.execute(phone_ins, (username, phone))
        conn.commit()

        # If there is a secondary phone number
        if request.form.get('check_aux_phone') == 'on':
            aux_phone = request.form['aux_phone']
            phone_ins = 'INSERT INTO staff_phone VALUES(%s, %s)'
            cursor.execute(phone_ins, (username, aux_phone))
            conn.commit()

        # If not already registered into table, create entry
        if not check_res:
            ins_wf = 'INSERT INTO works_for VALUES(%s, %s)'
            cursor.execute(ins_wf, (username, airline_employer))
            conn.commit()

        cursor.close()
        return render_template('index.html')

def user_auth(conn):
    # getting all the info for the Customer/ User (check ER)
    username = request.form['email'].replace("&", "&amp;").replace('"', "&quot;").replace("<", "&lt;").replace(">", "&gt;")
    name = request.form['name'].replace("&", "&amp;").replace('"', "&quot;").replace("<", "&lt;").replace(">", "&gt;")
    password = request.form['password']
    addr_num = request.form['addr_building_num']
    street = request.form['street']
    city = request.form['city']
    state = request.form['state']
    phone = request.form['phone']
    pass_num = request.form['passport_num']
    pass_exp = request.form['passport_exp']
    pass_country = request.form['passport_country']
    DoB = request.form['DoB']

    # query
    cursor = conn.cursor()
    query = 'SELECT * FROM customer WHERE email = %s'
    cursor.execute(query, (username))
    data = cursor.fetchone()
    error = None
    if (data):
        error = "This user already exists"
        return render_template('userreg.html', error=error)
    else:
        ins = 'INSERT INTO customer VALUES(%s, %s, MD5(%s), %s, %s, %s, %s, %s, %s, %s, %s, %s)'
        cursor.execute(ins, (username, name, password, addr_num, street, city, state, phone, pass_num, pass_exp, pass_country, DoB))
        conn.commit()
        cursor.close()
        return render_template('index.html')