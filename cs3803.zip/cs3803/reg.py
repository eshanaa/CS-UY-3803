from flask import Flask, render_template, request, session, url_for, redirect, abort
import pymysql.cursors
import datetime

def staff_reg(conn):
    cursor = conn.cursor()
    query = 'SELECT airline_name FROM airline'
    cursor.execute(query)
    airlines = cursor.fetchall()

    for airline in airlines:
        airline['visual'] = airline['airline_name']
        airline['airline_name'] = airline['airline_name'].replace(' ', '&nbsp;')

    cursor.close()

    if 'error' in session:
        error = session.pop('error')
        return render_template('staffreg.html', error=error, airlines=airlines)

    return render_template('staffreg.html', airlines=airlines)

def user_reg():
    return render_template('userreg.html')

def flight_reg(conn):
    airline = session["employer"]
    cursor = conn.cursor()
    all_flights = "SELECT F.airline_name, F.flight_number, F.depart_ts, F.airplane_id, F.arrival_ts, A.city AS arrival, D.city AS depart, F.flight_status, F.base_price FROM flights as F, airport as A, airport as D WHERE F.arrival_airport_code = A.code and F.depart_airport_code = D.code AND airline_name = %s ORDER BY depart_ts"
    cursor.execute(all_flights, (airline))
    flight_history = cursor.fetchall()
    cursor.close()
    return render_template('flightreg.html', company=airline, flights=flight_history)

def airplane_reg(conn):
    airline = session["employer"]
    cursor = conn.cursor()
    curr_owned = "SELECT airplane_id, num_seats FROM Airplane WHERE airline_name = %s"
    cursor.execute(curr_owned, (airline))
    planes = cursor.fetchall()
    cursor.close()
    return render_template('airplanereg.html', planes=planes, company=airline)

def airport_reg(conn):
    cursor = conn.cursor()
    all_airports = "SELECT * FROM Airport"
    cursor.execute(all_airports)
    airports = cursor.fetchall()
    cursor.close()
    return render_template('airportreg.html', airports=airports)
