from flask import Flask, render_template, request, session, url_for, redirect, abort
import pymysql.cursors
import datetime


def staff(cursor, username, password):
	query = 'SELECT * FROM airline_staff WHERE username = %s and staff_password = MD5(%s)'
	cursor.execute(query, (username, password))
	data = cursor.fetchone()

	query2 = 'SELECT * FROM Works_For WHERE username = %s'
	cursor.execute(query2, (username))
	data2 = cursor.fetchone()

	print(f"data2 = {data2}")
	session['employer'] = data2["airline_name"]
	session['type'] = 'staff'

	cursor.close()
	error = None

	if(data):
		session['username'] = username
		return redirect(url_for('home'))

	else:
		error = 'Invalid login or username'
		return render_template('login.html', error=error)

def customer(cursor, username, password):
	query = 'SELECT * FROM customer WHERE email = %s and customer_password = MD5(%s)'
	cursor.execute(query, (username, password))
	data = cursor.fetchone()
	cursor.close()

	error = None
	session['type'] = 'customer'

	if(data):
		session['username'] = username
		return redirect(url_for('home'))

	else:
		error = 'Invalid login or username'
		return render_template('login.html', error=error)


    