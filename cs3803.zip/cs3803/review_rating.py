from flask import Flask, render_template, request, session, url_for, redirect, abort
import pymysql.cursors
import datetime

def review(conn):
    username = session['username']
    curr_date = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    cursor = conn.cursor()
    get_prev_flights = 'SELECT flights.airline_name, flights.flight_number, flights.depart_ts, flights.arrival_ts, sell_price ' \
                       'FROM flights INNER JOIN ticket USING (flight_number) INNER JOIN purchases USING (ticket_id) ' \
                       'WHERE email = %s AND arrival_ts < %s'
    cursor.execute(get_prev_flights, (username, curr_date))
    res = cursor.fetchall()

    get_prev_reviews = 'SELECT airline_name, flight_number, depart_ts, rating, comments FROM reviews WHERE email = %s'
    cursor.execute(get_prev_reviews, (username))
    reviews = cursor.fetchall()
    cursor.close()

    if 'error' in session:
        error = session.pop('error')
        return render_template('reviewpage.html', res=res, reviews=reviews, error=error)
    return render_template('reviewpage.html', res=res, reviews=reviews)


def rating(conn):
    username = session['username']
    airline_name = request.form['airline_name']
    flight_num = request.form['flight_num']
    depart_ts = request.form['depart_ts']
    rating = request.form['rating']
    review = request.form['review'].replace("&", "&amp;").replace('"', "&quot;").replace("<", "&lt;").replace(">",
                                                                                                              "&gt;")
    current = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    cursor = conn.cursor()

    # query to get the departure time
    query = 'SELECT depart_ts FROM flights WHERE airline_name = %s AND flight_number = %s AND DATE(depart_ts) = %s'
    cursor.execute(query, (airline_name, flight_num, depart_ts))
    ts = cursor.fetchone()

    if not ts:
        cursor.close()
        session['error'] = 'Invalid Flight'
        return redirect(url_for('reviewpage'))

    depart_ts = ts['depart_ts']

    # query to get flights available to review
    query = 'SELECT * FROM flights INNER JOIN ticket USING (flight_number) INNER JOIN purchases USING (ticket_id) ' \
            'WHERE email = %s AND arrival_ts < %s AND flights.airline_name = %s AND flights.flight_number = %s AND flights.depart_ts = %s'
    cursor.execute(query, (username, current, airline_name, flight_num, depart_ts))
    res = cursor.fetchone()

    if not res:
        cursor.close()
        session['error'] = 'Invalid Flight'
        return redirect(url_for('reviewpage'))

    # query to check if the user already reviewed this flight
    query = 'SELECT * FROM reviews ' \
            'WHERE email = %s AND airline_name = %s AND flight_number = %s AND depart_ts = %s'
    cursor.execute(query, (username, airline_name, flight_num, depart_ts))
    res = cursor.fetchone()

    if res:
        cursor.close()
        session['error'] = 'You have already reviewed this flight!'
        return redirect(url_for('reviewpage'))

    # Insert ratings into the table
    vals = 'INSERT INTO reviews VALUES(%s, %s, %s, %s, %s, %s)'
    cursor.execute(vals, (username, airline_name, flight_num, depart_ts, rating, review))
    conn.commit()
    cursor.close()
    return redirect(url_for('reviewpage'))