from flask import Flask, render_template, request, session, url_for, redirect, abort
import pymysql.cursors
import datetime

def customer_home(conn, username):
    cursor = conn.cursor()
    display_name = 0

    query = "SELECT flights.airline_name, ticket.flight_number, depart_airport_code, arrival_airport_code, flights.depart_ts, arrival_ts, flight_status " \
            "FROM purchases INNER JOIN ticket USING (ticket_id) INNER JOIN flights USING (flight_number) " \
            "WHERE purchases.email = %s AND flights.arrival_ts > NOW()"
    cursor.execute(query, (username))
    customer_flights = cursor.fetchall()
    
    query = 'SELECT customer_name FROM customer WHERE email = %s'
    cursor.execute(query, (username))
    display_name = cursor.fetchone()[0]
    print(display_name)
    cursor.close()
    print(customer_flights)
    return render_template('home.html', customer_flights=customer_flights, display_name=display_name, usertype="customer")

def staff_home(conn, username):
    cursor = conn.cursor()
    query = 'SELECT first_name FROM airline_staff WHERE username = %s'
    cursor.execute(query, (username))
    display_name = cursor.fetchone()[0]
    cursor.close()
    return render_template('home.html', display_name= display_name, usertype= "staff")