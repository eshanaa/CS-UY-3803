from flask import Flask, render_template, request, session, url_for, redirect, abort
import pymysql.cursors
import datetime

def search_page():
    return render_template('search.html')

def search_flights(conn):
    src = request.form['src']
    dest = request.form['dest']
    dep_date = request.form['dep_date']
    cursor = conn.cursor()
    print(dep_date)
    query1 = "SELECT airline_name, flight_number, depart_ts, arrival_ts FROM flights WHERE " \
             "depart_airport_code = (SELECT code FROM airport WHERE airport_name = %s) AND " \
             "arrival_airport_code = (SELECT code FROM airport WHERE airport_name = %s) AND DATE(depart_ts) = %s"
    cursor.execute(query1, (src, dest, dep_date))
    data = cursor.fetchall()

    # to check if its a round trip
    if request.form.get('round_trip') == 'on':
        arr_date = request.form['arr_date']
        query2 = "SELECT airline_name, flight_number, depart_ts, arrival_ts FROM flights WHERE " \
                 "depart_airport_code = (SELECT code FROM airport WHERE airport_name = %s) AND " \
                 "arrival_airport_code = (SELECT code FROM airport WHERE airport_name = %s) AND DATE(depart_ts) = %s"
        cursor.execute(query2, (dest, src, arr_date))
        data += cursor.fetchall()

    print(data)
    cursor.close()
    if data:
        return render_template('search.html', res = data)
    else:
        return render_template('search.html', error = "No results!")