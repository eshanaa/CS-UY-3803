from login_auth import staff, customer
from reg import staff_reg, user_reg, flight_reg, airplane_reg, airport_reg
from reg_auth import staff_auth, user_auth
from home import customer_home, staff_home
from search import search_page, search
from review_rating import review, rating
from purchase import purchase_page, purchase_search, purchase_ticket, purchase_form
from analytics import financial, get_analytics
from customerhistory import view, get


from flask import Flask, render_template, request, session, url_for, redirect, abort
import pymysql.cursors
import datetime

app = Flask(__name__)

# Configure MySQL
################################# CONFIG ###################################
conn = pymysql.connect(host='localhost',
                       port=8889,
                       user='root',
                       password='',
                       db='airsystem',
                       charset='utf8mb4',
                       cursorclass=pymysql.cursors.DictCursor)


################################## INDEX ###################################

# Index Route: if user/staff already logged in
@app.route('/')
def index():
	if 'username' in session:
		return redirect(url_for('home'))
	return render_template('index.html')

################################## LOGIN ###################################

# Login Route
@app.route('/login')
def login():
	# Check if already logged in
	if 'username' in session:
		return redirect(url_for('home'))
	return render_template('login.html')

# User Login Authentication
@app.route('/loginAuth', methods=['GET','POST'])
def loginAuth():
	username = request.form['username']
	password = request.form['password']
	cursor = conn.cursor()
	# calls the appropriate login authentication method
	if request.form.get('login_type') == 'on':
		return staff(cursor, username, password)
	else:
		return customer(cursor, username, password)

################################## REGISTRATION ###################################

# Register Route
@app.route('/register')
def register():
	return render_template('regchoice.html')

# Register as User
@app.route('/userreg')
def userreg():
	return user_reg()

# Register as Staff
@app.route('/staffreg')
def staffreg():
	return staff_reg(conn)

# Register Authentication: Staff and User
@app.route('/registerAuth', methods=['GET', 'POST'])
def registerAuth():
	type = request.form['type']
	if type == 'staff':
		return staff_auth(conn)
	else:
		return user_auth(conn)

# Register a flight, not open to customers
@app.route('/flightreg')
def flightreg():
	if session['type'] == 'customer':
		abort(401)
	return flight_reg(conn)

# Register an airplane, not open to customers
@app.route('/airplanereg', methods=['GET', 'POST'])
def airplanereg():
	if session['type'] == 'customer':
		abort(401)
	return airplane_reg(conn)

# Register an airport, not open to customers
@app.route('/airportreg')
def airportreg():
	if session['type'] == 'customer':
		abort(401)
	return airport_reg(conn)

##################################### HOME ######################################

# Home Route
@app.route('/home')
def home():
	username=session['username']
	usertype=session['type']

	if 'error' in session:
		session.pop('error')

	if usertype =='customer':
		return customer_home(conn, username)

	elif usertype =='staff':
		return staff_home(conn, username)

##################################### SEARCH #####################################

# Search Page
@app.route('/searchpage')
def searchpage():
	return search_page()

# Search in the page
@app.route('/search', methods=['POST', 'GET'])
def search():
	return search(conn)

################################ PURCHASE  ######################################

# Purchase Page
@app.route('/purchasepage')
def purchasepage():
	if session['type'] == 'staff':
		abort(401)
	return purchase_page(conn)

# Purchase Search
@app.route('/purchaseSearch', methods=['POST'])
def purchaseSearch():
	if session['type'] == 'staff':
		abort(401)
	return purchase_search(conn)

# Purchase Ticket
@app.route('/purchaseTicket', methods=['POST'])
def purchaseTicket():
	if session['type'] == 'staff':
		abort(401)
	return purchase_ticket(conn)

# Purchase Form
@app.route('/purchaseForm', methods=['POST'])
def purchaseForm():
	if session['type'] == 'staff':
		abort(401)
	return purchase_form(conn)

################################ REVIEW/ RATING #######################################
# Ratings/ review page
@app.route('/reviewpage')
def reviewpage():
	if session['type'] == 'staff':
		abort(401)
	return review(conn)

@app.route('/leaverating', methods=['POST'])
def leaverating():
	if session['type'] == 'staff':
		abort(401)
	return rating(conn)

################################# SPENDING #######################################
# to view how much the user spending
@app.route('/viewspend', methods=['POST', 'GET'])
def viewspend():
	if session['type'] == 'staff':
		abort(401)

	username = session['username']
	cursor = conn.cursor()

	# query to get the total price of the tickets
	query = 'SELECT SUM(sell_price) as Total FROM purchases WHERE email = %s AND DATE(purchase_ts) >= %s AND DATE(purchase_ts) <= %s'
	spend_list = []

	if request.form.get('searched') == 'on':
		current = datetime.datetime.strptime(request.form['end'], "%Y-%m-%d")
		next = current - datetime.timedelta(days=31)
		limit = datetime.datetime.strptime(request.form['start'], "%Y-%m-%d")

		while (next > limit):
			cursor.execute(query, (username, next.strftime("%Y-%m-%d"), current.strftime("%Y-%m-%d")))
			response = cursor.fetchone()
			response['date_range'] = next.strftime("%Y-%m-%d") + ' to ' + current.strftime("%Y-%m-%d")
			spend_list.append(response)
			current = next
			next = next - datetime.timedelta(days = 31)

		# To execute query for the left over days
		cursor.execute(query, (username, limit.strftime("%Y-%m-%d"), current.strftime("%Y-%m-%d")))
		response = cursor.fetchone()
		response['date_range'] = limit.strftime("%Y-%m-%d") + ' to ' + current.strftime("%Y-%m-%d")
		spend_list.append(response)

	else:
		current = datetime.datetime.now()
		next = current - datetime.timedelta(days = 31)

		for month in range(6):
			cursor.execute(query, (username, next.strftime("%Y-%m-%d"), current.strftime("%Y-%m-%d")))
			response = cursor.fetchone()
			response['date_range'] = next.strftime("%Y-%m-%d") + ' to ' + current.strftime("%Y-%m-%d")
			spend_list.append(response)
			current = next
			next = next - datetime.timedelta(days = 31)

	# Total spending amount last year
	current = datetime.datetime.now()
	next = current - datetime.timedelta(days = 365)
	cursor.execute(query, (username, next.strftime("%Y-%m-%d"), current.strftime("%Y-%m-%d")))
	year_spent = cursor.fetchone()['Total']
	cursor.close()
	return render_template('viewspend.html', spend_list=spend_list, year_spent=year_spent)

################################# STAFF #######################################

@app.route('/staffview', methods=['GET', 'POST'])
def staffview():
	if session['type'] == 'customer':
		abort(401)

	username=session['username']
	airline = session["employer"]
	cursor = conn.cursor()

	# next month
	all_flights = "SELECT F.airline_name, F.flight_number, F.depart_ts, F.airplane_id, F.arrival_ts, A.city as arrival, D.city as depart, F.flight_status, F.base_price FROM flights as F, airport as A, airport as D WHERE F.arrival_airport_code = A.code and F.depart_airport_code = D.code AND airline_name = %s AND depart_ts BETWEEN NOW() and DATE_ADD(NOW(), INTERVAL 30 DAY) ORDER BY depart_ts"
	cursor.execute(all_flights, (airline))
	data = cursor.fetchall()
	cursor.close()
	return render_template('flightmanager.html', flights=data, username=username)

@app.route('/staffsearchflight', methods=['GET', 'POST'])
def staffsearchflight():
	if session['type'] == 'customer':
		abort(401)

	username=session['username']
	airline = session["employer"]
	cursor = conn.cursor()

	# next month
	all_flights = "SELECT F.airline_name, F.flight_number, F.depart_ts, F.airplane_id, F.arrival_ts, A.city as arrival, D.city as depart, F.flight_status, F.base_price FROM flights as F, airport as A, airport as D WHERE F.arrival_airport_code = A.code and F.depart_airport_code = D.code AND airline_name = %s AND depart_ts BETWEEN NOW() and DATE_ADD(NOW(), INTERVAL 30 DAY) ORDER BY depart_ts"
	cursor.execute(all_flights, (airline))
	data = cursor.fetchall()
	depart_ts_start = request.form['depart_ts_start']
	depart_ts_end = request.form['depart_ts_end']
	flight_number = request.form['flight_number']
	depart_airport = request.form['depart_airport']
	arrival_airport = request.form['arrival_airport']
	depart_city = request.form['depart_city']
	arrival_city = request.form['arrival_city']
	
	result = ""

	if(depart_ts_start != ''): 
		depart_ts_start = datetime.datetime.strptime(depart_ts_start, "%Y-%m-%d")
		if(depart_ts_end != ''): 
			depart_ts_end = datetime.datetime.strptime(depart_ts_end, "%Y-%m-%d")
			result = f"AND F.depart_ts BETWEEN '{depart_ts_start}' AND '{depart_ts_end}'"
		else:
			result = f"AND F.depart_ts >= '{depart_ts_start}'"

	elif(depart_ts_end != ''): 
		depart_ts_end = datetime.datetime.strptime(depart_ts_end, "%Y-%m-%d")
		result = f"AND F.depart_ts <= '{depart_ts_end}'"

	elif(flight_number != ''):
		result = f"AND F.flight_number = {flight_number}"

	elif(depart_airport != ''):
		if(arrival_airport != ''):
			result = f"AND D.airport_name = '{depart_airport}' AND A.airport_name = '{arrival_airport}'"
		else:
			result = f"AND D.airport_name = '{depart_airport}'"

	elif(arrival_airport != ''):
			result = f"AND A.airport_name = '{arrival_airport}'"


	elif(depart_city != ''):
		if(arrival_city != ''):
			result = f"AND D.city = '{depart_city}' AND A.city = '{arrival_city}'"
		else:
			result = f"AND D.city = '{depart_city}'"

	elif(arrival_city != ''):
			result = f"AND A.city = '{arrival_city}'"


	search_flights = f"SELECT F.airline_name, F.flight_number, F.depart_ts, F.airplane_id, F.arrival_ts, A.city as arrival, D.city as depart, F.flight_status, F.base_price FROM flights as F, airport as A, airport as D WHERE F.arrival_airport_code = A.code and F.depart_airport_code = D.code AND airline_name = %s {result} ORDER BY depart_ts"
	cursor.execute(search_flights, (airline))
	flight_range = cursor.fetchall()

	cursor.close()
	return render_template('flightmanager.html', flights=data, username=username, flights_in_range = flight_range)

@app.route('/staffaddplane', methods=['GET', 'POST'])
def staffaddplane():
	if session['type'] == 'customer':
		abort(401)

	airline = session["employer"]
	airplane_id = request.form['airplane_id']
	num_seats = request.form['num_seats']
	company = request.form['company']
	date = request.form['date']
	age = request.form['age']

	cursor = conn.cursor()

	#query to check if airplane already exists
	check_plane = "SELECT * FROM Airplane WHERE airline_name = %s AND airplane_id = %s"
	cursor.execute(check_plane, (airline, int(airplane_id)))
	data = cursor.fetchone()

	if(data): # plane exists
		error = f"This airplane already exists under {airline}"
		return render_template('airplanereg.html', error = error)
	
	# otherwise, we add it to the database
	insert_plane = "INSERT INTO Airplane VALUES(%s, %s, %s, %s, %s, %s)"
	cursor.execute(insert_plane, (airline, int(airplane_id), int(num_seats), company, date, age))
	conn.commit()


	#query to display all currently owned airplanes for company
	curr_owned = "SELECT airplane_id, num_seats FROM Airplane WHERE airline_name = %s"
	cursor.execute(curr_owned, (airline))
	planes = cursor.fetchall()
	cursor.close()

	return render_template('airplanereg.html', planes=planes, company=airline)

@app.route('/staffaddairport', methods=['GET', 'POST'])
def staffaddairport():
	if session['type'] == 'customer':
		abort(401)
		
	airport_name = request.form['airport_name']
	airport_code = request.form['airport_code']
	city = request.form['airport_city']
	country = request.form['airport_country']

	cursor = conn.cursor()

	#query to check if airport already exists
	check_airport = "SELECT * FROM Airport WHERE code = %s"
	cursor.execute(check_airport, (airport_code))
	data = cursor.fetchone()

	if(data): # airport exists
		error = f"An airport already exists with code {airport_code}"
		return render_template('airportreg.html', error = error)
	
	#otherwise, add to the database
	insert_airport = "INSERT INTO Airport VALUES(%s, %s, %s, %s)"
	cursor.execute(insert_airport, (int(airport_code), airport_name, city, country))
	conn.commit()

	#query to display all Airports in system
	get_airports = "SELECT * FROM Airport"
	cursor.execute(get_airports)
	airports = cursor.fetchall()
	cursor.close()
	return render_template('airportreg.html', airports=airports)

@app.route('/staffaddflight', methods=['GET', 'POST'])
def staffaddflight():
	#making sure only staff can access this page
	if session['type'] == 'customer':
		abort(401)

	airline = session["employer"]

	flight_number = request.form['flight_number']
	dep_ts = request.form['depart_ts']
	airplane_id = request.form['airplane_id']
	arr_ts = request.form['arrival_ts']
	dep_airport_code = request.form['depart_airport_code']
	arr_airport_code = request.form['arrival_airport_code']
	flight_status = request.form['flight_status']
	base_price = request.form['base_price']

	cursor = conn.cursor()

	all_flights = "SELECT * FROM Flights WHERE airline_name = %s"
	cursor.execute(all_flights, (airline))
	flight_history = cursor.fetchall()
	
	# query to check if arrival time comes before departure time
	if(datetime.datetime.fromisoformat(arr_ts) < datetime.datetime.fromisoformat(dep_ts)):
		error = "Arrival date comes before departure date"
		return render_template('flightreg.html', flights=flight_history, error=error, company=airline)

	# query to check if airplane belongs to airline
	check_plane = "SELECT * FROM airplane WHERE airline_name = %s AND airplane_id = %s"
	cursor.execute(check_plane, (airline, airplane_id))
	plane_owned = cursor.fetchall()

	if (not plane_owned):
		error = f"{airline} does not own plane with plane ID {airplane_id}"
		return render_template('flightreg.html', flights=flight_history, error=error, company=airline)

	# query to check if flight_number belongs to airline
	check_flight = "SELECT * FROM Flights WHERE airline_name = %s AND flight_number = %s"
	cursor.execute(check_flight, (airline, flight_number))
	check_flight_result = cursor.fetchall()

	if (check_flight_result):
		error = f"{airline} already has flight with flight number {flight_number}"
		return render_template('flightreg.html', flights=flight_history, error=error, company=airline)

	# query to see if flight already exists
	check_flight = "SELECT * FROM Flights WHERE airline_name = %s AND flight_number = %s AND depart_ts = %s"
	cursor.execute(check_flight, (airline, flight_number, dep_ts))
	data = cursor.fetchone()

	if(data): # flight must exist
		error = f"Flight {flight_number} for {airline} already exists"
		return render_template('flightreg.html', flights=flight_history, error=error, company=airline)
	
	#otherwise, add to the database
	new_flight = "INSERT INTO Flights VALUES(%s, %s, %s, %s, %s, %s, %s, %s, %s)"
	cursor.execute(new_flight, (airline, flight_number, dep_ts, airplane_id, arr_ts, dep_airport_code, arr_airport_code, flight_status, base_price))
	conn.commit()

	# query to get updated flights
	all_flights = "SELECT * FROM Flights WHERE airline_name = %s"
	cursor.execute(all_flights, (airline))
	flight_history = cursor.fetchall()
	cursor.close()

	return render_template('flightreg.html', flights=flight_history, company=airline)
	
@app.route('/manageflight', methods = ['GET', 'POST'])
def manageflight():
	#making sure only staff can access this page
	if session['type'] == 'customer':
		abort(401)

	airline = session["employer"]
	cursor = conn.cursor()

	check_flight = "SELECT F.airline_name, F.flight_number, F.depart_ts, F.airplane_id, F.arrival_ts, A.city as arrival, D.city as depart, F.flight_status, F.base_price FROM flights as F, airport as A, airport as D WHERE F.arrival_airport_code = A.code and F.depart_airport_code = D.code AND airline_name = %s"
	cursor.execute(check_flight, (airline))
	flights = cursor.fetchall()

	#count number of delayed flights
	count_delayed = "SELECT COUNT(flight_status) AS num_delayed FROM flights WHERE airline_name = %s AND flight_status= 'Delayed'"
	cursor.execute(count_delayed, (airline))
	num_delayed = cursor.fetchone()['num_delayed']

	# count number of on time flights
	count_ontime = "SELECT COUNT(flight_status) AS num_ontime FROM flights WHERE airline_name = %s AND flight_status= 'On-time'"
	cursor.execute(count_ontime, (airline))
	num_ontime = cursor.fetchone()['num_ontime']

	cursor.close()
	return render_template('modifyflight.html', flights=flights, num_delayed=num_delayed, num_ontime=num_ontime)

@app.route('/staffmodifyflight', methods = ['GET', 'POST'])
def staffmodifyflight():
	#making sure only staff can access this page
	if session['type'] == 'customer':
		abort(401)
	airline = session["employer"]
	flight_number = request.form['flight_number']
	status = request.form['status']
	cursor = conn.cursor()

	check_flight = "SELECT F.airline_name, F.flight_number, F.depart_ts, F.airplane_id, F.arrival_ts, A.city as arrival, D.city as depart, F.flight_status, F.base_price FROM flights as F, airport as A, airport as D WHERE F.arrival_airport_code = A.code and F.depart_airport_code = D.code AND airline_name = %s AND flight_number = %s"
	cursor.execute(check_flight, (airline, flight_number))
	flight_to_modify = cursor.fetchone()

	if (not flight_to_modify):
		error = "Flight not found"
		return render_template('modifyflight.html', error = error)

	#update the flight data 
	update_status = "UPDATE flights SET flight_status = %s WHERE flight_number = %s"
	cursor.execute(update_status, (status, flight_number))
	conn.commit()

	#query to display updated flight	
	check_flight = "SELECT F.airline_name, F.flight_number, F.depart_ts, F.airplane_id, F.arrival_ts, A.city as arrival, D.city as depart, F.flight_status, F.base_price FROM flights as F, airport as A, airport as D WHERE F.arrival_airport_code = A.code and F.depart_airport_code = D.code AND airline_name = %s"
	cursor.execute(check_flight, (airline))
	flight_to_modify = cursor.fetchall()

	cursor.close()

	return render_template('modifyflight.html', flights=flight_to_modify)

@app.route('/flightdetails', methods=['GET', 'POST'])
def flightdetails():
	#making sure only staff can access this page
	if session['type'] == 'customer':
		abort(401)

	airline = session["employer"]

	cursor = conn.cursor()
	get_avg_flightrating = "SELECT AVG(rating) AS 'average' FROM `reviews` WHERE airline_name = %s"
	cursor.execute(get_avg_flightrating, (airline))
	overall_average = cursor.fetchone()['average']

	cursor.close()

	return render_template('flightviewdetails.html', airline=airline, avgrating = overall_average)

@app.route('/getflightdetails', methods=['GET', 'POST'])
def flightratings():

	#making sure only staff can access this page
	if session['type'] == 'customer':
		abort(401)

	airline = session["employer"]

	flight_number = request.form['flight_number']
	cursor = conn.cursor()

	get_avg_flightrating = "SELECT AVG(rating) AS 'average' FROM `reviews` WHERE airline_name = %s"
	cursor.execute(get_avg_flightrating, (airline))
	overall_average = cursor.fetchone()['average']

	get_avgforflight = "SELECT AVG(rating) AS 'average' FROM `reviews` WHERE airline_name = %s AND flight_number = %s"
	cursor.execute(get_avgforflight, (airline, flight_number))
	avg_forflight = cursor.fetchone()

	if(not avg_forflight):
		error = f"Flight number {flight_number} not found."
		return render_template('flightviewdetails.html', airline=airline, avgrating = overall_average, error=error)

	check_flight = "SELECT F.airline_name, F.flight_number, F.depart_ts, F.airplane_id, F.arrival_ts, A.city as arrival, D.city as depart, F.flight_status, F.base_price FROM flights as F, airport as A, airport as D WHERE F.arrival_airport_code = A.code and F.depart_airport_code = D.code AND airline_name = %s AND flight_number = %s"
	cursor.execute(check_flight, (airline, flight_number))
	flights = cursor.fetchall()

	if(not flights):
		error = f"Flight number {flight_number} not found."
		return render_template('flightviewdetails.html', airline=airline, avgrating = overall_average, error=error)
	
	get_customers = "SELECT DISTINCT C.email AS email, C.customer_name AS name, C.phone_number AS phone_number, COUNT(C.email) AS tickets_purchased FROM Ticket AS T, Purchases AS P, Flights AS F, Customer AS C WHERE F.airline_name = %s AND F.flight_number = %s AND F.flight_number = T.flight_number AND T.ticket_id = P.ticket_id AND C.email = P.email GROUP BY(C.email)"
	cursor.execute(get_customers, (airline, flight_number))
	customers = cursor.fetchall()
	
	get_feedback = "SELECT email, rating, comments FROM reviews WHERE airline_name = %s AND flight_number = %s"
	cursor.execute(get_feedback, (airline, flight_number))
	comments = cursor.fetchall()
	cursor.close()
	return render_template('flightviewdetails.html', airline=airline, flights=flights, avgrating = overall_average, flight_number = flight_number, avgforflight=avg_forflight['average'], customers = customers, reviews=comments)


################################# ANALYTICS #######################################
# only staff can access this page

@app.route('/financialanalytics', methods = ['GET', 'POST'])
def financialanalytics():
	if session['type'] == 'customer':
		abort(401)
	return financial(conn)

@app.route('/getanalytics', methods = ['GET', 'POST'])
def getanalytics():
	if session['type'] == 'customer':
		abort(401)
	return get_analytics(conn)

################################# CUSTOMER HISTORY #######################################

@app.route('/viewcustomerhistory', methods=['GET', 'POST'])
def viewcustomerhistory():
	if session['type'] == 'customer':
		abort(401)
	return view()

@app.route('/getcustomerhistory', methods=['GET', 'POST'])
def getcustomerhistory():
	if session['type'] == 'customer':
		abort(401)
	return get(conn)

################################# LOGOUT #######################################

# Logout
@app.route('/logout')
def logout():
	if 'error' in session:
		session.pop('error')
	if 'ticket_id' in session:
		session.pop('ticket_id')
	if 'type' in session:
		sessiontype = session.pop('type')
		if sessiontype == 'staff':
			session.pop('employer')

	if 'username' in session:
		session.pop('username')

	return redirect('/')

if __name__ == '__main__':
	app.run(debug=True) # set to True for debugger
