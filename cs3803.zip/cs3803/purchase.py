from flask import Flask, render_template, request, session, url_for, redirect, abort
import pymysql.cursors
import datetime

def purchase_page(conn):
    a = 1

def purchase_search(conn):
    flight_num = request.form['flight_num']
    cursor = conn.cursor()
    query = 'SELECT * FROM ticket WHERE flight_number = %s AND ticket.ticket_id NOT IN (SELECT purchases.ticket_id FROM purchases)'
    cursor.execute(query, (flight_num))
    res = cursor.fetchall()
    cursor.close()

    return render_template('purchasepage.html', res=res, searched=True)


def purchase_ticket(conn):
    flight_number = request.form['flight_number']
    cursor = conn.cursor()
    query = 'SELECT COUNT(ticket_id) FROM ticket WHERE flight_number = %s AND ticket.ticket_id NOT IN (SELECT purchases.ticket_id FROM purchases)'
    cursor.execute(query, (flight_number))
    available_seats = cursor.fetchone()[0]

    query = 'SELECT airplane_id, base_price FROM flights WHERE flight_number = %s'
    cursor.execute(query, (flight_number))
    data = cursor.fetchone()

    if available_seats:
        airplane_id = data[0]
        base_price = data[1]

        query = 'SELECT num_seats FROM airplane WHERE airplane_id = %s'
        cursor.execute(query, (airplane_id))
        total_seats = cursor.fetchone()[0]

        cursor.close()
        if available_seats/total_seats < 0.2: 
            base_price *= 1.25

        return render_template('purchaseform.html', price = base_price)

    else:
        cursor.close()
        session['error'] = 'This ticket is not available!'
        return redirect(url_for('purchasepage'))


def purchase_form(conn):
    email = request.form['email']
    card_type = request.form['card_type']
    card_number = request.form['card_number']
    name_on_card = request.form['name_on_card']
    exp_date = request.form['exp_date']
    purchase_price = request.form['price']
    purchase_ts = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    ticket_id = 0

    # session 'cookie'
    if 'ticket_id' in session:
        ticket_id = session.pop('ticket_id')
    else:
        session['error'] = 'Session lost Ticket ID!'
        return redirect(url_for('purchasepage'))

    cursor = conn.cursor()
    vals = 'INSERT INTO purchases VALUES(%s, %s, %s, %s, %s, %s, %s, %s)'
    cursor.execute(vals, (ticket_id, email, card_type, card_number, name_on_card, exp_date, purchase_ts, purchase_price))
    conn.commit()
    cursor.close()

    return render_template('purchasesuccess.html')