from flask import Flask, render_template, request, session, url_for, redirect, abort
import pymysql.cursors
import datetime

def purchase_page(conn):
    cursor = conn.cursor()
    query = 'SELECT * FROM available_tickets'
    cursor.execute(query)
    res = cursor.fetchall()
    cursor.close()

    if 'error' in session:
        return render_template('purchasepage.html', res=res, searched=True, error=session.pop('error'))
    return render_template('purchasepage.html', res=res)

def purchase_search(conn):
    flight_num = request.form['flight_num']
    cursor = conn.cursor()
    query = 'SELECT * FROM ticket WHERE flight_number = %s AND ticket.ticket_id NOT IN (SELECT purchases.ticket_id FROM purchases)'
    cursor.execute(query, (flight_num))
    res = cursor.fetchall()
    cursor.close()

    return render_template('purchasepage.html', res=res, searched=True)


def purchase_ticket(conn):
    ticket_id = request.form['ticket_id']
    cursor = conn.cursor()
    query = 'SELECT * FROM available_tickets WHERE ticket_id = %s'
    cursor.execute(query, (ticket_id))
    res = cursor.fetchall()
    cursor.close()

    if res:
        session['ticket_id'] = ticket_id
        return render_template('purchaseform.html')

    else:
        session['error'] = 'This ticket is not available!'
        return redirect(url_for('purchasepage'))

def purchase_form(conn):
    email = request.form['email']
    card_type = request.form['card_type']
    card_number = request.form['card_number']
    name_on_card = request.form['name_on_card']
    exp_date = request.form['exp_date']
    purchase_ts = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    ticket_id, purchase_price = 0, 0

    # session 'cookie'
    if 'ticket_id' in session:
        ticket_id = session.pop('ticket_id')
    else:
        session['error'] = 'Session lost Ticket ID!'
        return redirect(url_for('purchasepage'))

    cursor = conn.cursor()

    # Last minute availability check
    query = 'SELECT price FROM available_tickets WHERE ticket_id = %s'
    cursor.execute(query, (ticket_id))
    res_price = cursor.fetchone()

    if res_price:
        purchase_price = res_price['price']
    else:
        cursor.close()
        session['error'] = 'This ticket is no longer available!'
        return redirect(url_for('purchasepage'))

    vals = 'INSERT INTO purchases VALUES(%s, %s, %s, %s, %s, %s, %s, %s)'

    cursor.execute(vals,
                   (ticket_id, email, card_type, card_number, name_on_card, exp_date, purchase_ts, purchase_price))
    conn.commit()
    cursor.close()

    return render_template('purchasesuccess.html')